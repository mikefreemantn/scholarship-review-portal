const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const sesClient = new SESClient({ region: 'us-east-1' });

// HTML email template
const emailTemplate = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Board Invitation</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background-color: #f5f5f0;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f0; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <tr>
                        <td style="background-color: #2d4a3e; padding: 50px 40px; text-align: center; background-image: repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,0.03) 20px, rgba(255,255,255,0.03) 40px);">
                            <h1 style="color: #ffffff; font-size: 36px; font-weight: bold; letter-spacing: 3px; margin: 0; text-transform: uppercase;">ONE MORE DAY</h1>
                            <p style="color: #d4c5a0; font-size: 14px; letter-spacing: 2px; margin: 10px 0 0; text-transform: uppercase;">On the Appalachian Trail</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 50px 40px;">
                            <h2 style="color: #2d4a3e; font-size: 28px; margin: 0 0 20px; font-weight: bold;">Welcome to the Review Board!</h2>
                            <p style="color: #555; font-size: 16px; line-height: 1.8; margin: 0 0 20px;">You have been invited to join the <strong>One More Day on the AT</strong> scholarship review board. We are honored to have you help us select this year's scholarship recipient.</p>
                            <p style="color: #555; font-size: 16px; line-height: 1.8; margin: 0 0 30px;">As a board member, you will:</p>
                            <table cellpadding="0" cellspacing="0" style="margin: 0 0 30px;">
                                <tr><td style="padding: 8px 0;"><span style="color: #2d4a3e; font-size: 20px; margin-right: 10px;">✓</span><span style="color: #555; font-size: 16px;">Review applicant profiles and video submissions</span></td></tr>
                                <tr><td style="padding: 8px 0;"><span style="color: #2d4a3e; font-size: 20px; margin-right: 10px;">✓</span><span style="color: #555; font-size: 16px;">Share notes with other board members</span></td></tr>
                                <tr><td style="padding: 8px 0;"><span style="color: #2d4a3e; font-size: 20px; margin-right: 10px;">✓</span><span style="color: #555; font-size: 16px;">Vote on each applicant using a 0-10 scale</span></td></tr>
                            </table>
                            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f8f5; border-left: 4px solid #2d4a3e; border-radius: 4px; margin: 30px 0;">
                                <tr>
                                    <td style="padding: 25px;">
                                        <h3 style="color: #2d4a3e; font-size: 18px; margin: 0 0 20px; font-weight: bold;">Your Login Credentials</h3>
                                        <table cellpadding="0" cellspacing="0" style="width: 100%;">
                                            <tr>
                                                <td style="padding: 12px; background-color: #ffffff; border-radius: 4px; margin-bottom: 10px;">
                                                    <div style="color: #888; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px;">Username</div>
                                                    <div style="color: #2d4a3e; font-size: 16px; font-weight: bold; font-family: 'Courier New', monospace;">{{EMAIL}}</div>
                                                </td>
                                            </tr>
                                            <tr><td style="height: 10px;"></td></tr>
                                            <tr>
                                                <td style="padding: 12px; background-color: #ffffff; border-radius: 4px;">
                                                    <div style="color: #888; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px;">Temporary Password</div>
                                                    <div style="color: #2d4a3e; font-size: 16px; font-weight: bold; font-family: 'Courier New', monospace;">{{PASSWORD}}</div>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            <p style="color: #555; font-size: 16px; line-height: 1.8; margin: 30px 0;">Click the button below to access the review portal. You'll be prompted to change your password on first login.</p>
                            <table cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="http://voting.onemoredayontheatapply.com" style="display: inline-block; background-color: #2d4a3e; color: #ffffff; text-decoration: none; padding: 16px 50px; border-radius: 4px; font-size: 16px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase;">Access Review Portal</a>
                                    </td>
                                </tr>
                            </table>
                            <p style="color: #888; font-size: 14px; line-height: 1.6; margin: 30px 0 0;">If you have any questions about the review process, please don't hesitate to reach out.</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #2d4a3e; padding: 40px; text-align: center;">
                            <div style="height: 60px; background: linear-gradient(to bottom, rgba(26,46,36,0), rgba(26,46,36,1)); margin-bottom: 20px;"></div>
                            <p style="color: #d4c5a0; font-size: 15px; font-style: italic; margin: 0 0 10px;">In Memory of <strong style="color: #ffffff;">Nate Loftis</strong> (1981 - 2019)</p>
                            <p style="color: #d4c5a0; font-size: 14px; line-height: 1.6; margin: 0 0 20px;">Honoring his memory by helping hikers<br>achieve their dreams on the Appalachian Trail</p>
                            <p style="color: #999; font-size: 12px; margin: 0;"><a href="http://onemoredayontheatapply.com" style="color: #d4c5a0; text-decoration: none;">onemoredayontheatapply.com</a></p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>`;

exports.handler = async (event) => {
    try {
        const { email, password, name } = JSON.parse(event.body);
        
        // Replace placeholders in template
        const htmlBody = emailTemplate
            .replace(/{{EMAIL}}/g, email)
            .replace(/{{PASSWORD}}/g, password);
        
        const params = {
            Source: 'mike@manovermachine.com',
            Destination: {
                ToAddresses: [email]
            },
            Message: {
                Subject: {
                    Data: 'One More Day on the AT - Review Board Invitation',
                    Charset: 'UTF-8'
                },
                Body: {
                    Html: {
                        Data: htmlBody,
                        Charset: 'UTF-8'
                    }
                }
            }
        };
        
        const command = new SendEmailCommand(params);
        const result = await sesClient.send(command);
        
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({
                success: true,
                messageId: result.MessageId
            })
        };
    } catch (error) {
        console.error('Error sending email:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                success: false,
                error: error.message
            })
        };
    }
};
